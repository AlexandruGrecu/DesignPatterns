
package patterns.command;

public interface Command {
  public void execute();
}
